﻿using System;

namespace Dewey_Training_DAL.Models
{
    public class Score
    {

        public string Username { get; set; }
        public string UserScore { get; set; }
        public DateTime DateTime { get; set; }

    }
}
