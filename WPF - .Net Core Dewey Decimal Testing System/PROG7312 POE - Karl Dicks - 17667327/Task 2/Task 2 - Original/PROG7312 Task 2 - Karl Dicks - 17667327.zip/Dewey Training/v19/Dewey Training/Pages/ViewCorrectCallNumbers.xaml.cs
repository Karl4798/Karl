﻿using System.Windows.Controls;

namespace Dewey_Training.Pages
{
    /// <summary>
    /// Karl Dicks - 17667327
    /// </summary>
    public partial class ViewCorrectCallNumbers : Page
    {
        public ViewCorrectCallNumbers()
        {
            InitializeComponent();
        }
    }
}
