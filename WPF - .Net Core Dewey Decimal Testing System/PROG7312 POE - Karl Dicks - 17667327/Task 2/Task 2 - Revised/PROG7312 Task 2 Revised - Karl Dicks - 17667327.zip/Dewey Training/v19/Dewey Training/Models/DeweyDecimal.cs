﻿namespace Dewey_Training.Models
{
    public class DeweyDecimal
    {

        public string Decimal { get; set; }
        public string Author { get; set; }

    }
}
